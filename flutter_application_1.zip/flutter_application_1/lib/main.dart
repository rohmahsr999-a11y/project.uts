import 'package:flutter/material.dart';

void main() {
  runApp(const StudentTodoApp());
}

// --- 1. Model Data ---
class Todo {
  String title;
  bool isDone;

  Todo({required this.title, this.isDone = false});
}

class StudentTodoApp extends StatelessWidget {
  const StudentTodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Study Planner',
      theme: ThemeData(
        // Skema Warna Estetika Kuliah: Navy Blue (Primer)
        primaryColor: const Color(0xFF19345D), // Deep Navy Blue
        scaffoldBackgroundColor: const Color(
          0xFFF0F4F8,
        ), // Background Light Grey-Blue
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF19345D),
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        // Aksen Teal Muda
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFF6DECB4), // Light Teal/Mint
          foregroundColor: Color(0xFF19345D),
          elevation: 6,
        ),
        colorScheme: ColorScheme.fromSwatch(
          primarySwatch: Colors.blueGrey,
        ).copyWith(secondary: const Color(0xFF6DECB4)),
        useMaterial3: true,
      ),
      home: const StudentTodoListScreen(),
    );
  }
}

// ---------------------------------------------
// --- 2. Halaman Utama To-Do List & CRUD Logic ---
// ---------------------------------------------

class StudentTodoListScreen extends StatefulWidget {
  const StudentTodoListScreen({super.key});

  @override
  State<StudentTodoListScreen> createState() => _StudentTodoListScreenState();
}

class _StudentTodoListScreenState extends State<StudentTodoListScreen> {
  // READ (R): Daftar Tugas
  final List<Todo> _todos = [
    Todo(title: 'Revisi Bab 3 Skripsi', isDone: false),
    Todo(title: 'Selesaikan Tugas Besar Matkul Aljabar', isDone: false),
    Todo(title: 'Baca Jurnal Penelitian (2 Artikel)', isDone: true),
  ];

  final TextEditingController _taskController = TextEditingController();

  @override
  void dispose() {
    _taskController.dispose();
    super.dispose();
  }

  // --- Fungsi CRUD ---

  // CREATE & UPDATE: Menambahkan/Mengubah tugas
  void _addOrUpdateTodoItem({int? indexToUpdate}) {
    final title = _taskController.text.trim();
    if (title.isNotEmpty) {
      setState(() {
        if (indexToUpdate != null) {
          _todos[indexToUpdate].title = title; // UPDATE
        } else {
          _todos.add(Todo(title: title)); // CREATE
        }
      });
      _taskController.clear();
      Navigator.of(context).pop();
    }
  }

  // UPDATE (U): Toggle status selesai
  void _toggleTodoStatus(int index) {
    setState(() {
      _todos[index].isDone = !_todos[index].isDone;
    });
  }

  // DELETE (D): Menghapus tugas
  void _removeTodoItem(int index) {
    final removedTask = _todos[index];
    setState(() {
      _todos.removeAt(index);
    });
    // SnackBar dengan opsi undo
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Tugas "${removedTask.title}" dihapus.'),
        backgroundColor: Theme.of(context).primaryColor,
        action: SnackBarAction(
          label: 'BATALKAN',
          textColor: Theme.of(context).colorScheme.secondary,
          onPressed: () {
            setState(() {
              _todos.insert(index, removedTask);
            });
          },
        ),
      ),
    );
  }

  // --- Form Modal (Create & Update) ---
  void _showTaskForm({Todo? todo, int? index}) {
    if (todo != null) {
      _taskController.text = todo.title;
    } else {
      _taskController.clear();
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(30.0)),
      ),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(
            top: 30,
            left: 25,
            right: 25,
            bottom: MediaQuery.of(context).viewInsets.bottom + 25,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                index == null ? '➕ Tugas Baru' : '✍️ Edit Penugasan',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).primaryColor,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 25),
              TextField(
                controller: _taskController,
                autofocus: true,
                decoration: InputDecoration(
                  labelText: 'Judul Tugas/Penugasan',
                  hintText: 'Misalnya: Kuis Kalkulus, Presentasi Kelompok',
                  prefixIcon: Icon(
                    Icons.menu_book,
                    color: Theme.of(context).primaryColor,
                  ),
                  labelStyle: TextStyle(color: Theme.of(context).primaryColor),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                      color: Theme.of(context).primaryColor,
                      width: 2,
                    ),
                    borderRadius: BorderRadius.circular(15),
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                onSubmitted: (_) => _addOrUpdateTodoItem(indexToUpdate: index),
              ),
              const SizedBox(height: 25),
              // Tombol Simpan/Tambah
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.secondary, // Aksen Teal
                  foregroundColor: Theme.of(context).primaryColor,
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 5,
                ),
                icon: Icon(
                  index == null ? Icons.save_alt : Icons.check_circle_outline,
                ),
                label: Text(
                  index == null ? 'TAMBAH TUGAS' : 'SIMPAN PERUBAHAN',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                onPressed: () => _addOrUpdateTodoItem(indexToUpdate: index),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Student Planner 🎓',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 28),
        ),
        centerTitle: true,
        toolbarHeight: 90,
      ),
      body: _todos.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.school_outlined,
                    size: 100,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 15),
                  const Text(
                    "Waktunya Belajar! Tidak ada penugasan hari ini.",
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              itemCount: _todos.length,
              itemBuilder: (context, index) {
                return StudentTodoCard(
                  todo: _todos[index],
                  index: index,
                  onToggle: _toggleTodoStatus,
                  onEdit: _showTaskForm, // Tombol UPDATE
                  onDismissed: _removeTodoItem, // Aksi DELETE (Swipe)
                );
              },
            ),
      // Tombol CREATE
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showTaskForm(todo: null, index: null),
        label: const Text('Buat Penugasan'),
        icon: const Icon(Icons.note_add_outlined),
        tooltip: 'Tambah Tugas Baru',
      ),
    );
  }
}

// ---------------------------------------------
// --- 3. Widget Desain Tugas (StudentTodoCard) ---
// ---------------------------------------------

class StudentTodoCard extends StatelessWidget {
  final Todo todo;
  final int index;
  final Function(int) onToggle;
  final Function(int) onDismissed;
  final Function({Todo todo, int index}) onEdit;

  const StudentTodoCard({
    super.key,
    required this.todo,
    required this.index,
    required this.onToggle,
    required this.onDismissed,
    required this.onEdit,
  });

  @override
  Widget build(BuildContext context) {
    final isDone = todo.isDone;

    return Dismissible(
      key: ValueKey(todo.title + index.toString()),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDismissed(index),
      // Background saat digeser (Aksi DELETE)
      background: Container(
        alignment: Alignment.centerRight,
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colors.red[700],
          borderRadius: BorderRadius.circular(15),
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              'ARCHIVE',
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(width: 8),
            Icon(
              Icons.archive_outlined,
              color: Colors.white,
              size: 30,
            ), // Ikon arsip/hapus yang elegan
          ],
        ),
      ),
      child: Card(
        // Desain Kartu dengan estetika minimalis dan shadow lembut
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        elevation: isDone ? 0 : 5,
        shadowColor: Theme.of(context).primaryColor.withOpacity(0.2),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(15),
          side: isDone
              ? BorderSide(
                  color: Colors.green.shade300,
                  width: 2,
                ) // Border hijau tipis jika selesai
              : BorderSide.none,
        ),
        child: InkWell(
          onTap: () => onToggle(index),
          borderRadius: BorderRadius.circular(15),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              vertical: 12.0,
              horizontal: 10.0,
            ),
            child: Row(
              children: [
                // 1. Tombol READ/UPDATE (Status)
                Checkbox(
                  value: isDone,
                  onChanged: (val) => onToggle(index),
                  activeColor: Theme.of(
                    context,
                  ).colorScheme.secondary, // Warna Teal
                  checkColor: Theme.of(
                    context,
                  ).primaryColor, // Tanda centang Navy
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      todo.title,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        decoration: isDone
                            ? TextDecoration.lineThrough
                            : TextDecoration.none,
                        color: isDone
                            ? Colors.grey[600]
                            : Theme.of(context).primaryColor,
                      ),
                    ),
                  ),
                ),
                // 2. Tombol UPDATE (Edit)
                Tooltip(
                  message: 'Ubah Detail Tugas',
                  child: IconButton(
                    icon: Icon(
                      Icons.edit_calendar_outlined,
                      color: isDone ? Colors.grey[400] : Colors.blueGrey,
                    ),
                    onPressed: isDone
                        ? null
                        : () => onEdit(todo: todo, index: index),
                  ),
                ),
                const SizedBox(width: 5),
                // 3. Tombol DELETE (Archive)
                Tooltip(
                  message: 'Arsipkan Tugas',
                  child: IconButton(
                    icon: Icon(
                      Icons.delete_outline,
                      color: Colors.red.shade400,
                    ),
                    onPressed: () => onDismissed(index),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
